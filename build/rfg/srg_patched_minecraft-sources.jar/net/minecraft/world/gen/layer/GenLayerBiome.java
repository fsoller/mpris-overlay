package net.minecraft.world.gen.layer;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.util.WeightedRandom;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.common.BiomeManager;
import net.minecraftforge.common.BiomeManager.BiomeEntry;

public class GenLayerBiome extends GenLayer
{
    private List<BiomeEntry>[] biomes = new ArrayList[BiomeManager.BiomeType.values().length];
    
    private static final String __OBFID = "CL_00000555";

    public GenLayerBiome(long p_i2122_1_, GenLayer p_i2122_3_, WorldType p_i2122_4_)
    {
        super(p_i2122_1_);
        
        this.field_75909_a = p_i2122_3_;
        
        for (BiomeManager.BiomeType type : BiomeManager.BiomeType.values())
        {
            com.google.common.collect.ImmutableList<BiomeEntry> biomesToAdd = BiomeManager.getBiomes(type);
            int idx = type.ordinal();
            
            if (biomes[idx] == null) biomes[idx] = new ArrayList<BiomeEntry>();
            if (biomesToAdd != null) biomes[idx].addAll(biomesToAdd);
        }
        
        int desertIdx = BiomeManager.BiomeType.DESERT.ordinal();
        
        if (p_i2122_4_ == WorldType.field_77136_e)
        {
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_76769_d, 10));
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_76767_f, 10));
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_76770_e, 10));
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_76780_h, 10));
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_76772_c, 10));
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_76768_g, 10));
        }
        else
        {
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_76769_d, 30));
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_150588_X, 20));
            biomes[desertIdx].add(new BiomeEntry(BiomeGenBase.field_76772_c, 10));
        }
    }

    public int[] func_75904_a(int p_75904_1_, int p_75904_2_, int p_75904_3_, int p_75904_4_)
    {
        int[] aint = this.field_75909_a.func_75904_a(p_75904_1_, p_75904_2_, p_75904_3_, p_75904_4_);
        int[] aint1 = IntCache.func_76445_a(p_75904_3_ * p_75904_4_);

        for (int i1 = 0; i1 < p_75904_4_; ++i1)
        {
            for (int j1 = 0; j1 < p_75904_3_; ++j1)
            {
                this.func_75903_a((long)(j1 + p_75904_1_), (long)(i1 + p_75904_2_));
                int k1 = aint[j1 + i1 * p_75904_3_];
                int l1 = (k1 & 3840) >> 8;
                k1 &= -3841;

                if (func_151618_b(k1))
                {
                    aint1[j1 + i1 * p_75904_3_] = k1;
                }
                else if (k1 == BiomeGenBase.field_76789_p.field_76756_M)
                {
                    aint1[j1 + i1 * p_75904_3_] = k1;
                }
                else if (k1 == 1)
                {
                    if (l1 > 0)
                    {
                        if (this.func_75902_a(3) == 0)
                        {
                            aint1[j1 + i1 * p_75904_3_] = BiomeGenBase.field_150608_ab.field_76756_M;
                        }
                        else
                        {
                            aint1[j1 + i1 * p_75904_3_] = BiomeGenBase.field_150607_aa.field_76756_M;
                        }
                    }
                    else
                    {
                        aint1[j1 + i1 * p_75904_3_] = getWeightedBiomeEntry(BiomeManager.BiomeType.DESERT).biome.field_76756_M;
                    }
                }
                else if (k1 == 2)
                {
                    if (l1 > 0)
                    {
                        aint1[j1 + i1 * p_75904_3_] = BiomeGenBase.field_76782_w.field_76756_M;
                    }
                    else
                    {
                        aint1[j1 + i1 * p_75904_3_] = getWeightedBiomeEntry(BiomeManager.BiomeType.WARM).biome.field_76756_M;
                    }
                }
                else if (k1 == 3)
                {
                    if (l1 > 0)
                    {
                        aint1[j1 + i1 * p_75904_3_] = BiomeGenBase.field_150578_U.field_76756_M;
                    }
                    else
                    {
                        aint1[j1 + i1 * p_75904_3_] = getWeightedBiomeEntry(BiomeManager.BiomeType.COOL).biome.field_76756_M;
                    }
                }
                else if (k1 == 4)
                {
                    aint1[j1 + i1 * p_75904_3_] = getWeightedBiomeEntry(BiomeManager.BiomeType.ICY).biome.field_76756_M;
                }
                else
                {
                    aint1[j1 + i1 * p_75904_3_] = BiomeGenBase.field_76789_p.field_76756_M;
                }
            }
        }

        return aint1;
    }
    
    protected BiomeEntry getWeightedBiomeEntry(BiomeManager.BiomeType type)
    {
        List<BiomeEntry> biomeList = biomes[type.ordinal()];
        int totalWeight = WeightedRandom.func_76272_a(biomeList);
        int weight = BiomeManager.isTypeListModded(type)?func_75902_a(totalWeight):func_75902_a(totalWeight / 10) * 10;
        return (BiomeEntry)WeightedRandom.getItem(biomeList, weight);
    }
}